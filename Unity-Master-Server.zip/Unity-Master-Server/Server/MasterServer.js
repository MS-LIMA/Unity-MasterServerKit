import fs from 'fs';
import { WebSocketServer } from 'ws';
import { onSocketMessage, onSocketClose } from './lib/ServerControl.js';

///////////////////////////////////////////////////////////////////////////
var ip = '';
var port = '';

///////////////////////////////////////////////////////////////////////////
// Read config file.
fs.readFile('config.json', 'utf8', (err, data) => {
    if (err) {
        console.error(err);
        return;
    }

    const json = JSON.parse(data);
    ip = json.server.ip;
    port = json.server.port;

    console.log(json);

    startServer(json);
});

///////////////////////////////////////////////////////////////////////////
// Start server.

const startServer = (config) => {
    var wss = new WebSocketServer({ port: port });
    console.log('Server opened on port %d.', port);

    wss.on('connection', function connection(socket) {    
        //console.log("Client connected");
        
        socket.on('message', (message) => {
            onSocketMessage(socket, message.toString());
        });
    
        socket.on('close', () => {
            //console.log("Client Disconnected");
            onSocketClose(socket);
        });
    });
}

