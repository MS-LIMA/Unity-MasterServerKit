using System.Collections;
using System.Collections.Generic;
using WebSocketSharp;
using UnityEngine;
using TMPro;
using Newtonsoft.Json;
using MS_Lima.MasterServer;
using MasterServer = MS_Lima.MasterServer.MasterServer;

public class MasterServerTest : MonoBehaviour
{
    [SerializeField] private GameObject Hide;
    [SerializeField] private TMP_InputField inputField;
    [SerializeField] private TMP_InputField nicknameField;

    [SerializeField] private GameObject roomView;
    [SerializeField] private Transform roomViewContentTransform;
    private Dictionary<string, RoomViewTest> roomViews = new Dictionary<string, RoomViewTest>();

    [SerializeField] private GameObject lobby;
    [SerializeField] private GameObject room;

    [SerializeField] private GameObject roomPlayerView;
    [SerializeField] private Transform roomPlayerViewContentTransform;

    [SerializeField] private TextMeshProUGUI playerCountText;

    private Dictionary<string, RoomPlayerViewTest> roomPlayers = new Dictionary<string, RoomPlayerViewTest>();

    private void Awake()
    {
        MasterServer.Player.Nickname = "���� " + Random.Range(0, 1000);
        MasterServer.Player.CustomProperties.Add("Obsv", true);

        MasterServer.onConnectedToMaster += () =>
        {
            Debug.Log("On Connected To Master");
            Hide.SetActive(false);

            MasterServer.GetPlayerCount();
            MasterServer.GetRoomList();
        };
        MasterServer.onPlayerCountUpdated += (int count) =>
        {
            playerCountText.text = count.ToString();
        };

        MasterServer.onCreatedRoom += () =>
        {
            lobby.SetActive(false);
            room.SetActive(true);

            Debug.Log("On Created Room");
        };
        MasterServer.onRoomInfoUpdated += (opRoom, roomInfo) =>
        {
            if (opRoom == OpRoom.OnCreated)
            {
                RoomViewTest roomViewTest = Instantiate(roomView, roomViewContentTransform).GetComponent<RoomViewTest>();
                roomViewTest.Init(roomInfo);
                roomViews.Add(roomInfo.id, roomViewTest);
            }
            else if (opRoom == OpRoom.OnPlayerJoined)
            {
                roomViews[roomInfo.id].Init(roomInfo);
            }

            Debug.Log("ON Room Info Updated");
        };
        MasterServer.onJoinedRoom += () =>
        {
            Debug.Log("On Joined Room");
            OnJoinedRoom();
        };
        MasterServer.onJoinRandomRoomFailed += (ErrorCode) =>
        {
            Debug.Log("On Join Random Room Failed " + ErrorCode);
        };
        MasterServer.onLeftRoom += () =>
        {
            lobby.SetActive(true);
            room.SetActive(false);
        };
        MasterServer.onPlayerJoined += (Player player) =>
        {
            RoomPlayerViewTest roomPlayerViewTest = Instantiate(roomPlayerView, roomPlayerViewContentTransform).GetComponent<RoomPlayerViewTest>();
            roomPlayerViewTest.Init(player.IsMaster, player.Nickname);

            roomPlayers.Add(player.Id, roomPlayerViewTest);
        };
        MasterServer.onPlayerLeft += (Player player) =>
        {
            RoomPlayerViewTest roomPlayerViewTest = roomPlayers[player.Id];
            Destroy(roomPlayerViewTest.gameObject);

            roomPlayers.Remove(player.Id);
        };
        MasterServer.onPlayerCustomPropertiesChanged += (Player player, Hashtable customProperties) =>
        {
            Debug.Log("PLAYER PROPERTY CHANGED");
            Debug.Log(JsonConvert.SerializeObject(customProperties));
            Debug.Log(JsonConvert.SerializeObject(player.CustomProperties));
        };
        MasterServer.onRoomCustomPropertiesChanged += (Hashtable customProperties) =>
        {
            Debug.Log("ROOM PROPERTY CHANGED");
            Debug.Log(JsonConvert.SerializeObject(customProperties));
            Debug.Log(JsonConvert.SerializeObject(MasterServer.Room.CustomProperties));
        };
    }

    private void Start()
    {
        MasterServer.ConnectToMaster();
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.G))
        {
            MasterServer.UpdateRoomCustomProperties(new Hashtable { { "map", "gogogogo" }, { "bam", "YEAH" } });
        }

        if (Input.GetKeyDown(KeyCode.H))
        {
            MasterServer.UpdatePlayerCustomProperties(MasterServer.Room.Master, new Hashtable { { "he", "wow" } });
        }
    }

    public void CreateRoom()
    {
        RoomOptions roomOptions = new RoomOptions();
        roomOptions.password = inputField.text;
        roomOptions.customProperties.Add("map", "hi");
        roomOptions.customProperties.Add("diff", "Hard");

        MasterServer.CreateRoom("�׽�Ʈ ���Դϴ�.", roomOptions);
    }

    public void JoinRandomRoom()
    {
        MasterServer.JoinRandomRoom();
    }

    public void LeaveRoom()
    {
        MasterServer.LeaveRoom();
    }

    private void OnJoinedRoom()
    {
        lobby.SetActive(false);
        room.SetActive(true);

        for (int i = 0; i < MasterServer.Room.PlayerList.Count; i++)
        {
            RoomPlayerViewTest roomPlayerViewTest = Instantiate(roomPlayerView, roomPlayerViewContentTransform).GetComponent<RoomPlayerViewTest>();
            roomPlayerViewTest.Init(MasterServer.Room.PlayerList[i].IsMaster, MasterServer.Room.PlayerList[i].Nickname);

            roomPlayers.Add(MasterServer.Room.PlayerList[i].Id, roomPlayerViewTest);
        }
    }


}
