using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace MS_Lima.MasterServer
{
    public class MasterServerBehaviour : MonoBehaviour
    {
        protected virtual void OnEnable()
        {
            MasterServer.onConnectedToMaster += OnConnectedToMaster;
            MasterServer.onCreatedRoom += OnCreatedRoom;
            MasterServer.onJoinedRoom += OnJoinedRoom;
            MasterServer.onJoinRoomFailed += OnJoinRoomFailed;
            MasterServer.onJoinRandomRoomFailed += OnJoinRandomRoomFailed;
            MasterServer.onLeftRoom += OnLeftRoom;
            MasterServer.onRoomInfoUpdated += OnRoomInfoUpdated;
            MasterServer.onPlayerJoined += OnPlayerJoined;
            MasterServer.onPlayerLeft += OnPlayerLeft;
            MasterServer.onMasterChanged += OnMasterChanged;
            MasterServer.onPlayerCustomPropertiesChanged += OnPlayerCustomPropertiesChanged;
            MasterServer.onRoomCustomPropertiesChanged += OnRoomCustomPropertiesChanged;
            MasterServer.onPlayerCountUpdated += OnPlayerCountUpdated;
            MasterServer.onPlayerCountInLobbyUpdated += OnPlayerCountInLobbyUpdated;
        }

        protected virtual void OnDisable()
        {
            MasterServer.onConnectedToMaster -= OnConnectedToMaster;
            MasterServer.onCreatedRoom -= OnCreatedRoom;
            MasterServer.onJoinedRoom -= OnJoinedRoom;
            MasterServer.onJoinRoomFailed -= OnJoinRoomFailed;
            MasterServer.onJoinRandomRoomFailed -= OnJoinRandomRoomFailed;
            MasterServer.onLeftRoom -= OnLeftRoom;
            MasterServer.onRoomInfoUpdated -= OnRoomInfoUpdated;
            MasterServer.onPlayerJoined -= OnPlayerJoined;
            MasterServer.onPlayerLeft -= OnPlayerLeft;
            MasterServer.onMasterChanged -= OnMasterChanged;
            MasterServer.onPlayerCustomPropertiesChanged -= OnPlayerCustomPropertiesChanged;
            MasterServer.onRoomCustomPropertiesChanged -= OnRoomCustomPropertiesChanged;
            MasterServer.onPlayerCountUpdated -= OnPlayerCountUpdated;
            MasterServer.onPlayerCountInLobbyUpdated -= OnPlayerCountInLobbyUpdated;
        }

        /// <summary>
        /// Called when connected to master server.
        /// </summary>
        public virtual void OnConnectedToMaster()
        {

        }

        /// <summary>
        /// Called when room created.
        /// </summary>
        public virtual void OnCreatedRoom()
        {

        }

        /// <summary>
        /// Called when joined room.
        /// </summary>
        public virtual void OnJoinedRoom()
        {

        }

        /// <summary>
        /// Called when join room failed.
        /// </summary>
        /// <param name="errorCode"></param>
        public virtual void OnJoinRoomFailed(ErrorCode errorCode)
        {

        }

        /// <summary>
        /// Called when join random room failed.
        /// </summary>
        /// <param name="errorCode"></param>
        public virtual void OnJoinRandomRoomFailed(ErrorCode errorCode)
        {

        }

        /// <summary>
        /// Called when left current room.
        /// </summary>
        public virtual void OnLeftRoom()
        {

        }

        /// <summary>
        /// Called when room info is updated in lobby.
        /// </summary>
        /// <param name="opRoom"></param>
        /// <param name="roomInfo"></param>
        public virtual void OnRoomInfoUpdated(OpRoom opRoom, RoomInfo roomInfo)
        {

        }


        /// <summary>
        /// Called when a player joined current room.
        /// </summary>
        /// <param name="player"></param>
        public virtual void OnPlayerJoined(Player player)
        {

        }

        /// <summary>
        /// Called when a player left current room.
        /// </summary>
        /// <param name="player"></param>
        public virtual void OnPlayerLeft(Player player)
        {

        }

        /// <summary>
        /// Called when a master client has been changed.
        /// </summary>
        /// <param name="player"></param>
        public virtual void OnMasterChanged(Player player)
        {

        }

        /// <summary>
        /// Called when a player's custom properties changed. 
        /// </summary>
        /// <param name="player"></param>
        /// <param name="propertiesChanged">Properties that has been changed</param>
        public virtual void OnPlayerCustomPropertiesChanged(Player player, Hashtable propertiesChanged)
        {

        }

        /// <summary>
        /// Called when a room's custom properties changed.
        /// </summary>
        /// <param name="propertiesChanged"></param>
        public virtual void OnRoomCustomPropertiesChanged(Hashtable propertiesChanged)
        {

        }

        /// <summary>
        /// Called when total player count updated. 
        /// </summary>
        /// <param name="playerCount"></param>
        public virtual void OnPlayerCountUpdated(int playerCount)
        {

        }

        /// <summary>
        /// Called when total player count in lobby updated.
        /// </summary>
        /// <param name="playerCountInLobby"></param>
        public virtual void OnPlayerCountInLobbyUpdated(int playerCountInLobby)
        {

        }
    }
}