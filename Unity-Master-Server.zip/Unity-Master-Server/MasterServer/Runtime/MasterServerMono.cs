using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using MS_Lima.MasterServer;

namespace MS_Lima.MasterServer
{
    public class MasterServerMono : MonoBehaviour
    {
        public static MasterServerMono Instance { get; private set; }
        private Queue<Action> callbacks = new Queue<Action>();

        private void Awake()
        {
            if (Instance == null)
            {
                Instance = this;
                DontDestroyOnLoad(this.gameObject);
            }
            else
            {
                Destroy(this.gameObject);
            }
        }

        private void Update()
        {
            lock (callbacks)
            {
                if (callbacks.Count > 0)
                {
                    while (callbacks.Count > 0)
                    {
                        Action action = callbacks.Dequeue();
                        action?.Invoke();
                    }
                }

            }
        }

        public static void EnqueueCallback(Action callback)
        {
            if (Instance == null)
                return;

            lock (Instance.callbacks)
            {
                Instance.callbacks.Enqueue(callback);
            }
        }

        private void OnApplicationQuit()
        {
            MasterServer.EndMasterSocketConnection();
        }
    }

}