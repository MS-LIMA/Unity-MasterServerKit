using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace MS_Lima.MasterServer
{
    public class Room
    {
        public string Id { get; private set; }
        public string Name { get; private set; }
        public Dictionary<string, Player> Players { get; private set; }
        public List<Player> PlayerList { get { return Players.Values.ToList(); } }
        public Player Master { get { return Players[MasterId]; } }
        public int PlayerCount { get { return Players.Count; } }
        public int MaxPlayerCount { get; private set; }
        public bool IsVisible { get; private set; }
        public bool IsLocked { get; private set; }
        public Hashtable CustomProperties { get; private set; }

        public string MasterId { get; set; }

        public Room(
            string id,
            string name,
            string masterId,
            Player[] players,
            int maxPlayerCount,
            bool isVisible,
            bool isLocked,
            Hashtable customProperties)
        {
            this.Players = new Dictionary<string, Player>();
            foreach (Player player in players)
                this.Players.Add(player.Id, player);

            this.Id = id;
            this.Name = name;

            this.MasterId = masterId;
            this.MaxPlayerCount = maxPlayerCount;
            this.IsVisible = isVisible;
            this.IsLocked = isLocked;
            this.CustomProperties = customProperties;
        }


    }

    public class RoomOptions
    {
        public int maxPlayerCount;
        public bool isVisible;
        public string password;
        public Hashtable customProperties;
        public string[] customPropertyKeysForLobby;

        public RoomOptions()
        {
            maxPlayerCount = 20;
            isVisible = true;
            password = "";
            customProperties = new Hashtable();
            customPropertyKeysForLobby = new string[] { };
        }
    }

    public struct RoomInfo
    {
        public string id;
        public string name;
        public bool isLocked;

        public int playerCount;
        public int maxPlayerCount;

        public Hashtable customProperties;
    }
}
