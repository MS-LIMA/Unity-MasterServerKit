using System;
using System.Collections;
using System.Collections.Generic;

using UnityEngine;
using Newtonsoft.Json;
using WebSocketSharp;
using Newtonsoft.Json.Linq;
using System.Threading;

namespace MS_Lima.MasterServer
{
    #region Operation and Enums
    public enum OpRequest : byte
    {
        ConnectToMaster = 0,

        CreateRoom = 1,
        JoinRoom = 2,
        JoinRandomRoom = 3,
        LeaveRoom = 4,

        UpdateRoomCustomProperties = 10,
        UpdatePlayerCustomProperties = 11,

        GetRoomList = 20,
        GetPlayerCount = 21,
        GetPlayerCountInLobby = 22,
    }

    public enum OpResponse : byte
    {
        OnConnectedToMaster = 0,
        OnConnectToMasterFailed = 1,

        OnCreatedRoom = 2,
        OnCreateRoomFailed = 3,
        OnJoinedRoom = 4,
        OnJoinedRandomRoom = 5,
        OnJoinRoomFailed = 6,
        OnJoinedRandomRoomFailed = 7,
        OnLeftRoom = 8,

        OnRoomListUpdated = 20,
        OnRoomUpdated = 21,
        OnPlayerCountUpdated = 22,
        OnPlayerCountInLobbyUpdated = 23,

        OnPlayerJoined = 30,
        OnPlayerLeft = 31,
        OnMasgerChanged = 32,
    }

    public enum OpRoom : byte
    {
        OnCreated = 0,
        OnPlayerJoined = 1,
        OnPlayerLeft = 2,
        OnMasterChanged = 3,
        OnPlayerKicked = 4,
        OnPasswordChanged = 5,
        OnRoomCustomPropertiesUpdated = 6,
        OnPlayerCustomPropertiesUpdated = 7,

        OnRemoved = 10,
    }

    public enum ErrorCode : byte
    {
        roomIsFull = 0,
        incorrectPassword = 1,
        roomNotFound = 2,
    }

    #endregion

    public class MasterServer
    {
        #region Modules
        private static MasterServerMono masterServerMono;
        private static WebSocket ws;
        #endregion

        #region Properties
        // Server.........................................................
        /// <summary>
        /// Is connected to master server?
        /// </summary>
        public static bool IsConnected { get; private set; }

        /// <summary>
        /// Total player count in master server.
        /// </summary>
        public static int PlayerCount { get; private set; }

        /// <summary>
        /// Player count only in lobby.
        /// </summary>
        public static int PlayerCountInLobby { get; private set; }

        // Room.........................................................
        /// <summary>
        /// Is in room?
        /// </summary>
        public static bool InRoom { get; private set; }

        /// <summary>
        /// Current room.
        /// </summary>
        public static Room Room { get; private set; }

        // Player.......................................................
        /// <summary>
        /// Local player.
        /// </summary>
        public static Player Player { get; private set; } = new Player();

        #endregion

        #region Configs
        private static string authenticateId = "";
        private static MasterServerConfig masterServerConfig;
        #endregion

        #region Callbacks
        public static Action onConnectedToMaster;
        public static Action onCreatedRoom;
        public static Action<OpRoom, RoomInfo> onRoomInfoUpdated;
        public static Action onJoinedRoom;
        public static Action<ErrorCode> onJoinRoomFailed;
        public static Action<ErrorCode> onJoinRandomRoomFailed;
        public static Action onLeftRoom;

        public static Action<Player> onPlayerJoined;
        public static Action<Player> onPlayerLeft;
        public static Action<Player> onMasterChanged;
        public static Action<Player, Hashtable> onPlayerCustomPropertiesChanged;
        public static Action<Hashtable> onRoomCustomPropertiesChanged;

        public static Action<int> onPlayerCountUpdated;
        public static Action<int> onPlayerCountInLobbyUpdated;
        #endregion

        #region Socket Methods
        private static void InitWebSockets()
        {
            if (masterServerMono == null)
            {
                GameObject monoObject = new GameObject("MasterServerMono");
                masterServerMono = monoObject.AddComponent<MasterServerMono>();
            }

            masterServerConfig = Resources.Load<MasterServerConfig>("MasterServerConfig");


            string uri = string.Format("ws://{0}:{1}", masterServerConfig.ip, masterServerConfig.port);
            ws = new WebSocket(uri);
            ws.OnOpen += OnSocketOpen;
            ws.OnClose += OnSocketClose;
            ws.OnMessage += OnSocketMessage;
            ws.OnError += OnSocketError;

            ws.ConnectAsync();
        }

        private static void OnSocketMessage(object sender, MessageEventArgs e)
        {
            //Debug.Log(e.Data);

            MasterServerMono.EnqueueCallback(() =>
            {
                dynamic obj = JsonConvert.DeserializeObject<dynamic>(e.Data);
                var opResponse = obj.opResponse;

                switch ((OpResponse)opResponse)
                {
                    case OpResponse.OnConnectedToMaster:
                        OnConnectedToMaster(obj.body);
                        break;
                    case OpResponse.OnCreatedRoom:
                        OnCreatedRoom(obj.body);
                        break;
                    case OpResponse.OnRoomListUpdated:
                        OnRoomListUpdated(obj.body);
                        break;
                    case OpResponse.OnJoinedRoom:
                    case OpResponse.OnJoinedRandomRoom:
                        OnJoinedRoom(obj.body);
                        break;
                    case OpResponse.OnJoinRoomFailed:
                        OnJoinRoomFailed(obj.body);
                        break;
                    case OpResponse.OnJoinedRandomRoomFailed:
                        OnJoinRandomRoomFailed(obj.body);
                        break;
                    case OpResponse.OnLeftRoom:
                        OnLeftRoom(obj.body);
                        break;
                    case OpResponse.OnRoomUpdated:
                        OnRoomUpdated(obj.body);
                        break;
                    case OpResponse.OnPlayerCountUpdated:
                        OnPlayerCountUpdated(obj.body);
                        break;
                    case OpResponse.OnPlayerCountInLobbyUpdated:
                        OnPlayerCountInLobbyUpdated(obj.body);
                        break;
                }
            });
        }

        private static void OnSocketOpen(object sender, System.EventArgs e)
        {
            Debug.Log("Socket Open");

            if (!IsConnected)
            {
                AuthenticateUser();
            }
        }

        private static void OnSocketClose(object sender, CloseEventArgs e)
        {
            Debug.Log("Socket Close");
        }

        private static void OnSocketError(object sender, ErrorEventArgs e)
        {
            Debug.Log(e.Message);
        }

        #endregion

        #region Connect To Master
        /// <summary>
        /// Connect to master server. If authenticateId is not provided, random uuid will given
        /// which distinguishes each players.
        /// </summary>
        /// <param name="authenticateId"></param>
        public static void ConnectToMaster(string authenticateId = null)
        {
            MasterServer.authenticateId = authenticateId;
            InitWebSockets();
        }

        private static void AuthenticateUser()
        {
            var data = new
            {
                opRequest = OpRequest.ConnectToMaster,
                version = masterServerConfig.version,
                body = new
                {
                    id = MasterServer.authenticateId
                }
            };

            string json = JsonConvert.SerializeObject(data);
            ws.Send(json);
        }

        private static void OnConnectedToMaster(dynamic body)
        {
            string id = body.id;
            Player.Id = id;

            onConnectedToMaster?.Invoke();
        }
        #endregion

        #region Create Room
        /// <summary>
        /// Create room with room name and room options.
        /// </summary>
        /// <param name="roomName"></param>
        /// <param name="roomOptions"></param>
        public static void CreateRoom(string roomName, RoomOptions roomOptions = null)
        {
            if (roomOptions == null)
                roomOptions = new RoomOptions();

            var obj = new
            {
                opRequest = OpRequest.CreateRoom,
                version = masterServerConfig.version,
                body = new
                {
                    masterInfo = new { id = Player.Id, nickname = Player.Nickname, customProperties = Player.CustomProperties },
                    roomName = roomName,
                    roomOptions = roomOptions
                }
            };

            string json = JsonConvert.SerializeObject(obj);
            ws.Send(json);
        }

        private static void OnCreatedRoom(dynamic body)
        {
            InRoom = true;
            Room = CreateRoomInstance(body);

            onCreatedRoom?.Invoke();
            onJoinedRoom?.Invoke();
        }
        #endregion

        #region Join Room
        /// <summary>
        /// Join room by room id. If room is locked, correct password must be provided to join.
        /// </summary>
        /// <param name="roomId"></param>
        /// <param name="password"></param>
        public static void JoinRoom(string roomId, string password = null)
        {
            var obj = new
            {
                opRequest = OpRequest.JoinRoom,
                version = masterServerConfig.version,
                body = new
                {
                    joinerInfo = new { id = Player.Id, nickname = Player.Nickname, customProperties = Player.CustomProperties },
                    roomId = roomId,
                    password = password
                }
            };

            string json = JsonConvert.SerializeObject(obj);
            ws.Send(json);
        }

        /// <summary>
        /// Join random room. Rooms which are not full and has no password are only considered.
        /// </summary>
        public static void JoinRandomRoom()
        {
            var obj = new
            {
                opRequest = OpRequest.JoinRandomRoom,
                version = masterServerConfig.version,
                body = new
                {
                    joinerInfo = new { id = Player.Id, nickname = Player.Nickname, customProperties = Player.CustomProperties },
                }
            };

            string json = JsonConvert.SerializeObject(obj);
            ws.Send(json);

        }

        private static void OnJoinedRoom(dynamic body)
        {
            InRoom = true;
            Room = CreateRoomInstance(body);

            onJoinedRoom?.Invoke();
        }

        private static void OnJoinRoomFailed(dynamic body)
        {
            ErrorCode errorCode = body.errorCode;
            onJoinRoomFailed?.Invoke(errorCode);
        }

        private static void OnJoinRandomRoomFailed(dynamic body)
        {
            ErrorCode errorCode = body.errorCode;
            onJoinRoomFailed?.Invoke(errorCode);
        }

        #endregion

        #region Leave Room
        /// <summary>
        /// Leave current room.
        /// </summary>
        public static void LeaveRoom()
        {
            var obj = new
            {
                opRequest = OpRequest.LeaveRoom,
                version = masterServerConfig.version,
                body = new
                {
                    leaverInfo = new { id = Player.Id },
                    roomId = MasterServer.Room.Id
                }
            };

            string json = JsonConvert.SerializeObject(obj);
            ws.Send(json);
        }

        private static void OnLeftRoom(dynamic body)
        {
            InRoom = false;
            Room = null;

            onLeftRoom?.Invoke();
        }

        #endregion

        #region Lobby Control
        private static void OnRoomListUpdated(dynamic body)
        {
            dynamic infos = body.roomInfos;
            for (int i = 0; i < infos.Count; i++)
            {
                OpRoom opRoom = infos[i].opRoom;
                JObject roomInfoJObject = infos[i].roomInfo;
                RoomInfo roomInfo = roomInfoJObject.ToObject<RoomInfo>();

                onRoomInfoUpdated?.Invoke(opRoom, roomInfo);
            }
        }

        /// <summary>
        /// Get all room list in current lobby. 
        /// </summary>
        public static void GetRoomList()
        {
            var obj = new
            {
                opRequest = OpRequest.GetRoomList,
                version = masterServerConfig.version,
            };

            string json = JsonConvert.SerializeObject(obj);
            ws.Send(json);
        }

        /// <summary>
        /// Get total player count in master server.
        /// </summary>
        public static void GetPlayerCount()
        {
            var obj = new
            {
                opRequest = OpRequest.GetPlayerCount,
                version = masterServerConfig.version,
            };

            string json = JsonConvert.SerializeObject(obj);
            ws.Send(json);
        }

        /// <summary>
        /// Get total player count only in lobby.
        /// </summary>
        public static void GetPlayerCountInLobby()
        {
            var obj = new
            {
                opRequest = OpRequest.GetPlayerCountInLobby,
                version = masterServerConfig.version,
            };

            string json = JsonConvert.SerializeObject(obj);
            ws.Send(json);
        }

        private static void OnPlayerCountUpdated(dynamic body)
        {
            int count = body.playerCount;
            PlayerCount = count;

            onPlayerCountUpdated?.Invoke(count);
        }

        private static void OnPlayerCountInLobbyUpdated(dynamic body)
        {
            int count = body.playerCountInLobby;
            PlayerCountInLobby = count;

            onPlayerCountInLobbyUpdated?.Invoke(count);
        }
        #endregion

        #region In Room Control
        private static void OnRoomUpdated(dynamic body)
        {
            OpRoom opRoom = body.opRoom;
            switch (opRoom)
            {
                case OpRoom.OnPlayerJoined:
                    OnPlayerJoined(body.joiner);
                    break;
                case OpRoom.OnPlayerLeft:
                    OnPlayerLeft(body.leaverId);
                    break;
                case OpRoom.OnMasterChanged:
                    OnMasterChanged(body.masterId);
                    break;
                case OpRoom.OnRoomCustomPropertiesUpdated:
                    OnRoomCustomPropertiesChanged(body.customProperties);
                    break;
                case OpRoom.OnPlayerCustomPropertiesUpdated:
                    OnPlayerCustomPropertiesChanged(body.playerId, body.customProperties);
                    break;
            }
        }

        private static void OnPlayerJoined(dynamic joiner)
        {
            JObject joinerObject = joiner;
            Player player = joinerObject.ToObject<Player>();
            Room.Players.Add(player.Id, player);

            onPlayerJoined?.Invoke(player);
        }

        private static void OnPlayerLeft(dynamic leaverId)
        {
            string id = leaverId;
            Player player = Room.Players[id];
            Room.Players.Remove(id);

            onPlayerLeft?.Invoke(player);
        }

        private static void OnMasterChanged(dynamic masterId)
        {
            string id = masterId;
            Player player = Room.Players[masterId];
            Room.MasterId = id;

            onMasterChanged?.Invoke(player);
        }

        /// <summary>
        /// Update current room's custom properties. Only work in room.
        /// </summary>
        /// <param name="customProperties"></param>
        public static void UpdateRoomCustomProperties(Hashtable customProperties)
        {
            var obj = new
            {
                opRequest = OpRequest.UpdateRoomCustomProperties,
                version = masterServerConfig.version,
                body = new
                {
                    roomId = Room.Id,
                    customProperties = customProperties
                }
            };

            string json = JsonConvert.SerializeObject(obj);
            ws.Send(json);
        }

        /// <summary>
        /// Update specific player's custom properties. Only work in room.
        /// </summary>
        /// <param name="player"></param>
        /// <param name="customProperties"></param>
        public static void UpdatePlayerCustomProperties(Player player, Hashtable customProperties)
        {
            var obj = new
            {
                opRequest = OpRequest.UpdatePlayerCustomProperties,
                version = masterServerConfig.version,
                body = new
                {
                    playerInfo = new { id = player.Id },
                    roomId = Room.Id,
                    customProperties = customProperties
                }
            };

            string json = JsonConvert.SerializeObject(obj);
            ws.Send(json);
        }

        private static void OnPlayerCustomPropertiesChanged(dynamic pId, dynamic hashtable)
        {
            string playerId = pId;
            JObject cpJObject = hashtable;
            Hashtable customProperties = cpJObject.ToObject<Hashtable>();

            Player player = Room.Players[playerId];
            foreach (object key in customProperties.Keys)
            {
                if (player.CustomProperties.ContainsKey(key))
                    player.CustomProperties[key] = customProperties[key];
                else
                    player.CustomProperties.Add(key, customProperties[key]);
            }

            onPlayerCustomPropertiesChanged?.Invoke(player, customProperties);
        }

        private static void OnRoomCustomPropertiesChanged(dynamic hashtable)
        {
            JObject cpJObject = hashtable;
            Hashtable customProperties = cpJObject.ToObject<Hashtable>();
            foreach (object key in customProperties.Keys)
            {
                if (Room.CustomProperties.ContainsKey(key))
                    Room.CustomProperties[key] = customProperties[key];
                else
                    Room.CustomProperties.Add(key, customProperties[key]);
            }

            onRoomCustomPropertiesChanged?.Invoke(customProperties);
        }
        #endregion

        #region Misc
        private static Room CreateRoomInstance(dynamic body)
        {
            string id = body.roomInfo.id;
            string roomName = body.roomInfo.name;
            string masterId = body.roomInfo.masterId;

            JArray playersJObject = body.roomInfo.players;
            Player[] players = playersJObject.ToObject<Player[]>();

            int maxPlayerCount = body.roomInfo.maxPlayerCount;
            bool isVisible = body.roomInfo.isVisible;
            bool isLocked = body.roomInfo.isLocked;

            JObject customPropertiesJObject = body.roomInfo.customProperties;
            Hashtable customProperties = customPropertiesJObject.ToObject<Hashtable>();

            Room room = new Room(
                id,
                roomName,
                masterId,
                players,
                maxPlayerCount,
                isVisible,
                isLocked,
                customProperties
                );

            return room;
        }

        public static void EndMasterSocketConnection()
        {
            ws.Close();
        }
        #endregion
    }
}