using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MS_Lima.MasterServer;

namespace MS_Lima.MasterServer
{
    [CreateAssetMenu(fileName = "MasterServerConfig", menuName = "MasterServer/Config", order = 1)]
    public class MasterServerConfig : ScriptableObject
    {
        public string ip;
        public string port;

        [Space(5f)]
        public string version;
    }
}

