using System.Collections;
using System.Collections.Generic;
using MS_Lima.MasterServer;

namespace MS_Lima.MasterServer
{
    public class Player
    {
        public string Id { get; set; }
        public string Nickname { get; set; }
        public Hashtable CustomProperties { get; set; }

        public bool IsMaster
        {
            get
            {
                if (MasterServer.Room != null)
                {
                    return MasterServer.Room.Master.Id == Id;
                }
                else
                {
                    return false;
                }
            }
        }

        public Player()
        {
            this.Id = "";
            this.Nickname = "";
            this.CustomProperties = new Hashtable();
        }
    }
}
