using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class RoomPlayerViewTest : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI nicknameText;

    public void Init(bool isMaster, string nickname)
    {
        nicknameText.text = string.Format("{0}{1}", isMaster ? "����" : "" , nickname);
    }
}
