using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using MS_Lima.MasterServer;
using MasterServer = MS_Lima.MasterServer.MasterServer;

public class RoomViewTest : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI roomNameText;
    [SerializeField] private TextMeshProUGUI playerCountText;

    public RoomInfo roomInfo;

    public void Init(RoomInfo roomInfo)
    {
        this.roomInfo = roomInfo;
        roomNameText.text = string.Format("{0}{1}", roomInfo.isLocked ? "[���]" : "", roomInfo.name);
        playerCountText.text = string.Format("{0} / {1}", roomInfo.playerCount, roomInfo.maxPlayerCount);
    }

    public void OnClick()
    {
        MasterServer.JoinRoom(roomInfo.id);
    }
}
